#!/bin/bash
# Run this in container!
cd /tmp/web1
phpunit tests
